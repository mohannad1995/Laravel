
@extends('layout.app')
  
       
             @section('content')
              @include('includes.slider') 
            <div class="content">
                <div class="title m-b-md">
                <div class="container">
                  Muhammed Essa
                </div></div>
            </div>
               @endsection