<?php
symlink('/fast-beyond-88645/storage/app/public','/fast-beyond-88645/public/storage');


 