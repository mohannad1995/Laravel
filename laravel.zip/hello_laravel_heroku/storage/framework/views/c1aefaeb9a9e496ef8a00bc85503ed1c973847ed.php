<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                   <a href="/posts/create" class="btn btn-primary btn-lg">New post !</a>
                
                
                <hr>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <h3 class="panel-title"><?php echo e($post->subject); ?></h3>
                    </div>
                    <div class="panel-body">
                        <?php echo $post->body; ?>


  
                    </div>
    <div class="panel-footer">
     <a   href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-primary  ">Edit</a>
  
  <?php echo Form::open(['action' => ['PostsController@destroy',$post->id], 'method'=>'POST']); ?>

  <?php echo e(Form::hidden('_method' ,'DELETE')); ?>

   <?php echo e(Form::submit('Delete',['class'=>"pull-right btn btn-danger btn-sm"])); ?>

<?php echo Form::close(); ?>

    
    </div>                
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                
                </div>
            </div>
        </div>
    </div>
</div>









<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>