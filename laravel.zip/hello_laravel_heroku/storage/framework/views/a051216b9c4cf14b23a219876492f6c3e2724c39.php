           
           
            <?php $__env->startSection('content'); ?>
            <div class="content">
                <div class="container">
                <h1>Posts</h1>

<?php if(count($posts) >0): ?>


            
 <div class="row container">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-sm-4">
  
  <div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title"><?php echo e($post->firstname); ?> - <?php echo e($post->lastname); ?></h3>
  </div>
  <div class="panel-body">
    <h2> <?php echo e($post->subject); ?></h2> 

 

 <img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($post->post_image); ?>" class="img-thumbnail" alt="<?php echo e($post->post_image); ?>" style="width:50%,height:50%" > 


   <span class="label label-danger">created at : <?php echo e($post->created_at); ?>  </span>
     <span class="label label-info">  by <?php echo e($post->user->name); ?></span>

   <a class="pull-right" href="/posts/<?php echo e($post->id); ?>" class="btn btn-warning">More</a>
  </div>
</div>
  
  </div>
   
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php echo e($posts->links()); ?>

</div>

</div>
 
</div>
           

<?php else: ?>


<div class="alert alert-dismissible alert-danger">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <strong>Oh  !</strong> <a href="#" class="alert-link">No posts !</a> and try submitting again.
</div>



<?php endif; ?>

           <?php $__env->stopSection(); ?>



 


<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>