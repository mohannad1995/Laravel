  
       
             <?php $__env->startSection('content'); ?>
              <?php echo $__env->make('includes.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
            <div class="content">
                <div class="title m-b-md">
                <div class="container">
                  Muhammed Essa
                </div></div>
            </div>
               <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>