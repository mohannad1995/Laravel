         
 
         <?php $__env->startSection('content'); ?>
            <div class="content">
                <div class="title m-b-md">
                  Programming languages
                </div>
            </div>
            
            
            <div class="content">
                <div class="title m-b-md">
                <ul>
                 <?php $__currentLoopData = $myname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mynames): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>   <?php echo e($mynames); ?></li>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </ul>
                </div>
            </div>




            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>