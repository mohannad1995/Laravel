           
           
            <?php $__env->startSection('content'); ?>
         <div class="panel panel-danger container">
  <div class="panel-heading">
    <h3 class="panel-title"><?php echo e($post->firstname); ?> - <?php echo e($post->lastname); ?>

   
   
    </h3></div>
   <?php if(!Auth::guest()): ?>
   <?php if(Auth::user()->id == $post->user_id): ?>

    <a class="pull-right" href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-warning">Edit</a>


  
  <div class="panel-body">



  <?php echo Form::open(['action' => ['PostsController@destroy',$post->id], 'method'=>'POST']); ?>

  <?php echo e(Form::hidden('_method' ,'DELETE')); ?>

   <?php echo e(Form::submit('Delete',['class'=>"pull-right btn btn-danger btn-lg"])); ?>

<?php echo Form::close(); ?>

<?php endif; ?>
<?php endif; ?>

 
  
 <img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($post->post_image); ?>" class="img-thumbnail" alt="<?php echo e($post->post_image); ?>" style="width:50%,height:50%" > 



  
    <h2> <?php echo e($post->subject); ?></h2> 
     <p> <?php echo $post->body; ?></p>
   <span class="label label-danger">created at : <?php echo e($post->created_at); ?></span>
 <span class="label label-info">  by <?php echo e($post->user->name); ?></span>

  </div>
  <a class="pull-right" href="/posts" class="btn btn-warning">Back</a>
</div>


           <?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>