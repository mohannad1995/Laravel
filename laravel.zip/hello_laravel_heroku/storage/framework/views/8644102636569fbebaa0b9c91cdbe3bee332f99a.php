           
           
            <?php $__env->startSection('content'); ?>
           
           
<?php echo Form::open(['action' => 'PostsController@store', 'method'=>'POST','enctype'=>'multipart/form-data']); ?>

 

   <div class=container>
<div class="form-group">
      <?php echo e(Form::label('subject', 'Subject')); ?>

      <?php echo e(Form::text('subject','' , ['class'=>'form-control'] )); ?>

    </div>
 <div class="form-group">
      <?php echo e(Form::label('firstname', 'First name')); ?>

      <?php echo e(Form::text('firstname','',['class'=>'form-control'])); ?>

    </div>

<div class="form-group">
      <?php echo e(Form::label('lastname', 'Last name')); ?>

      <?php echo e(Form::text('lastname','',['class'=>'form-control' ])); ?>

    </div>

<div class="form-group">
      <?php echo e(Form::label('body', 'Discriptions')); ?>

      <?php echo e(Form::textarea('body','',['class'=>'form-control' ,'id'=>'article-ckeditor'])); ?>

    </div>

   
 
<div class="form-group">
      
      <?php echo e(Form::file('post_image', ['class'=>'btn ' ])); ?>

    </div>   
 
<?php echo e(Form::submit('Create',['class'=>'btn btn-primary btn-lg' ] )); ?>


   </div>


<?php echo Form::close(); ?>

 
    
           <?php $__env->stopSection(); ?>



 


<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>